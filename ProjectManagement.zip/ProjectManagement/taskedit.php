<?php
session_start();
include("dbconnect.php");
if(isset($_SESSION['regid']))
{
$regid=$_SESSION['regid'];
$sql="select * from registeration where slno=$regid";
$result=mysqli_query($link,$sql);
while($sql1=mysqli_fetch_array($result,MYSQLI_NUM))
{
$name=$sql1[4];
}
}
else
{
header("Location:index.html");
}

?> 
<!-- email_id,password,confirm_password,user_type -->

<?php
include("dbconnect.php");
$project_name=$_POST['project_name'];
$task_name=$_POST['task_name'];
$alloted_hours=$_POST['alloted_hours'];
$deadline=$_POST['dob'];
$status=$_POST['status'];


$id=$_POST['id'];
$sql="update tasks set project_name='$project_name',task_name='$task_name',alloted_hours='$alloted_hours',deadline='$deadline',status='$status' where slno='$id'";
echo $sql;
if(mysqli_query($link,$sql))
{
	header("Location:tasks.php");
}
else
{
	echo"error".$sql."<br>".mysqli_error($link);
}

?>