<?php
include("dbconnect.php");
$project_name=$_POST['project_name'];

$status=$_POST['status'];

$sql="insert into projects(project_name,status)
values('$project_name','$status')";

if(mysqli_query($link,$sql))
{
	header("Location:projects.php");
}
else
{
	header("Location:error.html");
}
?>