First you've to Import the database .
You can check the working video 