<?php
session_start();
SESSION_DESTROY();
header("Location:index.html");
//alert(echo "logout successfully...!!!";);
?>