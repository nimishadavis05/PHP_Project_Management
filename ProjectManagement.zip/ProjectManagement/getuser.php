<main>
        

                     
        <table class="table table-hover">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Project Name</th>
                
                <th scope="col">Status</th>
                 
              </tr>
            </thead>
            <tbody>
            
<?php
include("dbconnect.php");
 
  if (isset($_POST['query'])) {
      $query = "SELECT * FROM projects WHERE project_name LIKE '{$_POST['query']}%' LIMIT 100";
      $result = mysqli_query($link, $query);
    if (mysqli_num_rows($result) > 0) {
        while ($sql1 = mysqli_fetch_array($result)) {
          echo "<tr><td>";
        	echo $sql1[0]."</td><td>".$sql1[1]."</td><td>".$sql1[2]."</td><td><a href='generate_report.php?id=$sql1[0]' target='_blank'>View Report</a></td>";
          echo "</tr>";
      }
    } else {
      echo "
      <div class='alert alert-danger mt-3 text-center' role='alert'>
          Project not found
      </div>
      ";
    }
  }
?>