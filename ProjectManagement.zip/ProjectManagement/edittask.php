<?php
session_start();
include("dbconnect.php");
if(isset($_SESSION['regid']))
{
$regid=$_SESSION['regid'];
$sql="select * from registeration where slno=$regid";
$result=mysqli_query($link,$sql);
while($sql1=mysqli_fetch_array($result,MYSQLI_NUM))
{
$name=$sql1[4];
}
}
else
{
header("Location:index.html");
}

?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>dashboard</title>
    <link rel="stylesheet" href="main.css">
</head>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">
<body class="home">
    <div class="container-fluid display-table">
        <div class="row display-table-row">
            <div class="col-md-2 col-sm-1 hidden-xs display-table-cell v-align box" id="navigation">
                <div class="logo">
                   <h2 style="color:white">DASHBOARD</h2>
                </div>
                <div class="navi">
                    <ul>
                        <li ><a href="dashboard.php"><i class="fa fa-home" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Home</span></a></li>
                        <li ><a href="employee.php"><i class="fa fa-user" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Employee</span></a></li>
                        <li ><a href="projects.php"><i class="fa fa-tasks" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Projects</span></a></li>
                        <li class="active"><a href="tasks.php"><i class="fa fa-calendar" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Tasks</span></a></li>
                        <li><a href="report.php"><i class="fa fa-bar-chart" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Report</span></a></li>
                        <li><a href="settings.php"><i class="fa fa-cog" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Setting</span></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-10 col-sm-11 display-table-cell v-align">
                <!--<button type="button" class="slide-toggle">Slide Toggle</button> -->
                <div class="row">
                    <header>
                        <div class="col-md-7">
                            <nav class="navbar-default pull-left">
                                <div class="navbar-header">
                                    <button type="button" class="navbar-toggle collapsed" data-toggle="offcanvas" data-target="#side-menu" aria-expanded="false">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                </div>
                            </nav>
                            <div class="search hidden-xs hidden-sm">
                                <input type="text" placeholder="Search" id="search">
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="header-rightside">
                                <ul class="list-inline header-top pull-right">
                                    <a href="logout.php" >Logout</a>
                                   </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </header>
                </div>
                <div class="user-dashboard">
                    <h1>Edit Task</h1>
                    <div class="row">
                        <div class="col-md-5 col-sm-5 col-xs-12 gutter">

                             
                                
                            
                        </div>
                        <main>

                        <?php
include("dbconnect.php");
if(isset($_GET['id']))
{
$regid=$_GET['id'];
$sql="select *,DATE(deadline) as date  from  tasks where slno='$regid' ";
//echo $sql;
$result=mysqli_query($link,$sql);
while($sql1=mysqli_fetch_array($result,MYSQLI_NUM))
{
	
	$project_name=$sql1[1];
	$task_name=$sql1[2];
    $descri=$sql1[3];
	$alloted_hours=$sql1[4];
    $status=$sql1[6];
    
    $deadline=$sql1[5];
	
	
	$id=$sql1[0];
}
}
?>
      
        <form action="taskedit.php" method="post">
        <input type="hidden" name="id" value="<?php echo $id; ?>">
            <div class="preview text-center">
      
                <div class="browse-button">
                    <i class="fa fa-pencil-alt"></i>
                    
                </div>
                <div>
                    <br>
                </div>
            </div>
            <div class="form-group">
                Project:
                <select name='project_name' required>
                    
                <option value="<?php echo $project_name; ?>" >
                <?php echo $project_name; ?>
                <?php echo "</option>" ?>
        
                    
                <?php
include("dbconnect.php");
$SQL="select * from projects  ";

$result=mysqli_query($link,$SQL);
while($sql1=mysqli_fetch_array($result,MYSQLI_NUM)):;
?>
           
              
  <option value="<?php echo $sql1[1];?>">
                    <?php echo $sql1[1];
                        
                    ?>
                </option>
                <?php 
                endwhile; 
                // While loop must be terminated
            ?>
        </select>
                
                <span class="Error"></span>
            </div>

            <div class="form-group">
                
                Choose Status:


                <select name="status"  required>
                 
                <option value="<?php echo $status; ?>" >
                <?php echo $status; ?>
                <?php echo "</option>" ?>
        <option value="active">Active</option>
            <option value="inactive">InActive</option>
                    
                            
                   
                </select>
                <span class="Error"></span>
            </div>


            <div class="form-group">
                
                <input class="form-control" type="text" name="task_name" value="<?php echo $task_name; ?>" required placeholder="Enter Task"/>
                <span class="Error"></span>
            </div>
            <div class="form-group">
                
                <input class="form-control" type="text" name="descri"  value="<?php echo $descri; ?>" required placeholder="Description"/>
                <span class="Error"></span>
            </div>
            <div class="form-group">
                
                <input class="form-control" type="text" name="alloted_hours"  value="<?php echo $alloted_hours; ?>" required placeholder="Enter Alloted Hours for Task"/>
                <span class="Error"></span>
            </div>
            <div class="form-group">
                Task Deadline:
                <input type="date" name="dob"   value="<?php echo $deadline; ?>" required>
                <span class="Error"></span>
            </div>
            
            <div class="form-group">
                <input class="btn btn-primary btn-block" type="submit" value="Submit"/>
            </div>
        </form>
    </div>

                        
</main>
                    </div>
                </div>
            </div>
        </div>

    </div>



    <!-- Modal -->
    
    <script src="main.js"></script>
</body>
    

</html>