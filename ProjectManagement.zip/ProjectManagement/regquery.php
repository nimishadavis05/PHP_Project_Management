<?php
include("dbconnect.php");
$email=$_POST['Username'];
$password=$_POST['Password'];
$cpassword=$_POST['CPassword'];
$user_type="user";
$sql="insert into registeration(email_id,password,confirm_password,user_type)
values('$email','$password','$cpassword','$user_type')";

if(mysqli_query($link,$sql))
{
	header("Location:index.html");
}
else
{
	header("Location:regfail.html");
}
?>