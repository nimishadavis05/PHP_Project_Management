<?php
session_start();
include("dbconnect.php");
try
{
$username=$_POST['Username'];
$password=$_POST['Password'];
$user_type=$_POST['user_type'];
$sql="SELECT * FROM registeration WHERE email_id='$username' AND password='$password'";
$result=mysqli_query($link,$sql);
$counter=0;
if($result==FALSE)
{
	echo"error".$sql."<br>".mysqli_error($link);
}
while($row=mysqli_fetch_array($result,MYSQLI_NUM))
{
	$counter=1;
	$regid=$row[0];
	$temp=$row[4];
}
if($counter>0 && $temp!='admin' )
{
	$_SESSION['regid']=$regid;
	header("Location:user_index.php");

	//exit();
}
else if($counter>0 && $temp=='admin' )
{
	
	

$_SESSION['regid']=$regid;
	header("Location:dashboard.php");

	
}
else{
	
    header("Location:logfail.html");
    exit();

}
}
catch(Exception $e)
{
  echo $e;
}
?>  
