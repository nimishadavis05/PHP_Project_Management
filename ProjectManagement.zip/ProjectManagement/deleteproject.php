<?php
include("dbconnect.php");
if(isset($_GET['id']))
{
$eventid=$_GET['id'];
$sql="select * from  projects where id='$eventid'";
//echo $sql;
$result=mysqli_query($link,$sql);
while($sql1=mysqli_fetch_array($result,MYSQLI_NUM))
{
	
	
	$project_name=$sql1[1];
	$status=$sql1[2];
	
	$id=$sql1[0];
}
}
$sql="delete from projects  where id='$id'";
echo $sql;
if(mysqli_query($link,$sql))
{
	header("Location:projects.php");
}
else
{
	header("Location:projects.php");
}

?>