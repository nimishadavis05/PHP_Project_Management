<?php
$link=mysqli_connect('localhost','root','');
$db="pm";
if(!$link)
{
die("could not connect".mysqli_error());
}
else
{
//echo'connected successfully';
}
$db=mysqli_select_db($link,"pm");
if(!$db)
{
	die('could not select:'.mysqli_error($link));
}
else
{
	//echo 'could select';
}
?>