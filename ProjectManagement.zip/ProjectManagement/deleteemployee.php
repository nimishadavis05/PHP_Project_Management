<?php
include("dbconnect.php");
if(isset($_GET['id']))
{
$eventid=$_GET['id'];
$sql="select * from  registeration where slno='$eventid'";
//echo $sql;
$result=mysqli_query($link,$sql);
while($sql1=mysqli_fetch_array($result,MYSQLI_NUM))
{
	
	
	$email=$sql1[1];
	$password=$sql1[2];
	
	$id=$sql1[0];
}
}
$sql="delete from registeration  where slno='$id'";
echo $sql;
if(mysqli_query($link,$sql))
{
	header("Location:employee.php");
}
else
{
	header("Location:employee.php");
}

?>