<?php
session_start();
include("dbconnect.php");
if(isset($_SESSION['regid']))
{
$regid=$_SESSION['regid'];
$sql="select * from registeration where slno=$regid";
$result=mysqli_query($link,$sql);
while($sql1=mysqli_fetch_array($result,MYSQLI_NUM))
{
$name=$sql1[4];
}
}
else
{
header("Location:index.html");
}

?> 
<!-- email_id,password,confirm_password,user_type -->

<?php
include("dbconnect.php");
$username=$_POST['Username'];
$password=$_POST['Password'];
$cpassword=$_POST['Password'];

$id=$_POST['id'];
$sql="update registeration set email_id='$username',password='$password',confirm_password='$cpassword' where slno='$id'";
echo $sql;
if(mysqli_query($link,$sql))
{
	header("Location:employee.php");
}
else
{
	echo"error".$sql."<br>".mysqli_error($link);
}

?>