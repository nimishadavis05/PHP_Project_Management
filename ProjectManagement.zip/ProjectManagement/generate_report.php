<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="main.css">

    


</head>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<body class="home">

<div class="user-dashboard">
                    
                    
                    <div class="row">
                        <div class="col-md-5 col-sm-5 col-xs-12 gutter">

                            
                                
                                     
                                    
                                   
                                
                            
                        </div>
                        <main>

        

                     
        
                        <?php
include("dbconnect.php");
if(isset($_GET['id']))
{
$regid=$_GET['id'];
$sql="select * from  projects where id='$regid'";
//echo $sql;
$result=mysqli_query($link,$sql);
while($sql1=mysqli_fetch_array($result,MYSQLI_NUM))
{
	
	$project_name=$sql1[1];
    $status=$sql1[2];
	$id=$sql1[0];
}
}
//echo $uploadfile;
?>
<h1><center><tr><big><?php echo $project_name;?></big>'s Report</tr></center></h1>
<hr>
  

<b>Project Status</b>:<?php echo $status;?><br>

<hr>
                     
<table class="table table-hover">
            <thead>
              <tr>
                <th scope="col">Tasks</th>
                
                <th scope="col">Alloted Hours</th>
                
                <th scope="col">Deadline</th>
                <th scope="col">Status</th>
              </tr>
            </thead>
            <tbody>
            


            <?php
include("dbconnect.php");
// $SQL="select * from projects where id='$regid' ";
$SQL="SELECT  projects.status,tasks.task_name,tasks.descri,tasks.alloted_hours,tasks.deadline,tasks.status FROM   projects,tasks WHERE  projects.id='$regid'";

$result=mysqli_query($link,$SQL);

while($sql1=mysqli_fetch_array($result,MYSQLI_NUM))
{
	echo "<tr><td>";
	echo $sql1[1]."</td><td>".$sql1[3]."</td><td>".$sql1[4]."</td><td>".$sql1[5]."</td>";
   echo "</tr>";


}


?>
      </tbody>
</table>

</body>
<br> <button onClick="window.print()"> Print Report</button>
</html>