<?php
include("dbconnect.php");
$project_name=$_POST['project_name'];
$task_name=$_POST['task_name'];
$descri=$_POST['descri'];
$alloted_hours=$_POST['alloted_hours'];

$deadline=$_POST['dob'];
$status=$_POST['status'];

$sql="insert into tasks(project_name,task_name,alloted_hours,status,deadline,descri)
values('$project_name','$task_name','$alloted_hours','$status','$deadline','$descri')";

if(mysqli_query($link,$sql))
{
	header("Location:tasks.php");
}
else
{
	header("Location:error.html");
}
?>